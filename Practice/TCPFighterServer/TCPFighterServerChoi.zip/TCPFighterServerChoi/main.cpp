﻿#pragma comment(lib, "ws2_32")
#pragma comment(lib, "winmm.lib")

#include <WinSock2.h>
#include <Windows.h>
#include <WS2tcpip.h>
#include <stdio.h>
#include <tchar.h>
#include <list>

#include "RingBUffer.h"
#include "PacketDefine.h"


// 게임프레임 : 50fps
#define SERVER_PORT 5000
#define BUFFER_SIZE 10000
#define dfNETWORK_PACKET_CODE 0x89

// 화면 이동영역--------------------------
#define dfRANGE_MOVE_TOP	50
#define dfRANGE_MOVE_LEFT	10
#define dfRANGE_MOVE_RIGHT	630
#define dfRANGE_MOVE_BOTTOM	470

//위 좌표에 가지 못하게 해야하며,
//해당 좌표에 닿는 경우 움직임을 멈추어야 함.
//(작거나 같으면 멈춤)
//예) 왼쪽 상단으로 이동 중 왼쪽 범위에 걸리면
//상단으로 벽을 타고 이동하는게 아니며, 그자리에 멈춰야 함.
//왜냐면!!클라이언트가 그렇게 만들어 졌기 때문에, 서버도 그렇게 만들어 져야만 함

//-----------------------------------------------------------------
// 프레임당 이동 단위
//-----------------------------------------------------------------
#define dfMOVE_X 3
#define dfMOVE_Y 3

//-----------------------------------------------------------------
// 이동 오류체크 범위
//-----------------------------------------------------------------
#define dfERROR_RANGE		50

//---------------------------------------------------------------
// 공격범위.
//---------------------------------------------------------------
#define dfATTACK1_RANGE_X		80
#define dfATTACK2_RANGE_X		90
#define dfATTACK3_RANGE_X		100
#define dfATTACK1_RANGE_Y		10
#define dfATTACK2_RANGE_Y		10
#define dfATTACK3_RANGE_Y		20

//---------------------------------------------------------------
// 공격 데미지.
//---------------------------------------------------------------
#define dfATTACK1_DAMAGE		3
#define dfATTACK2_DAMAGE		5
#define dfATTACK3_DAMAGE		10


// 캐릭터 초기 설정
#define MAX_HP					100

struct Session
{
	SOCKET socket; // 현 접속의 TCP 소켓
	SOCKADDR_IN addr;

	wchar_t   ipStr[32];
	USHORT port;

	DWORD sessionID; // 접속자의 고유 세션 ID
	RingBuffer recvQ; // 수신 큐
	RingBuffer sendQ; // 송신 큐

	DWORD action;
	BYTE direction;

	short x;
	short y;

	char HP;
};

bool gbShutdown = false;
DWORD gAllocID = 1;
SOCKET gListenSocket = INVALID_SOCKET;
std::list<Session*> gSessionList;

// 타이밍(단위: QPC counts)
LARGE_INTEGER gFreq;
LARGE_INTEGER gFrameStartTick;
LARGE_INTEGER gFrameEndTick;


void Update() noexcept;
bool MoveCheck(BYTE direction, int x, int y) noexcept;

void NetIOProcess() noexcept;
void NetProc_Accept() noexcept;
void NetProc_Recv(Session*) noexcept;
void NetProc_Send(Session*) noexcept;

bool PacketProc(Session* pSession, BYTE byPacketType, char* pPacket);
bool NetPacketProc_MoveStart(Session* pSession, char* pPacket);
bool NetPacketProc_MoveStop(Session* pSession, char* pPacket);
bool NetPacketProc_Attack1(Session* pSession, char* pPacket);
bool NetPacketProc_Attack2(Session* pSession, char* pPacket);
bool NetPacketProc_Attack3(Session* pSession, char* pPacket);

// 패킷 생성
void MakePacket_CreateMyCharacter(PacketHeader* pHeader, PacketSCCreateMyCharacter* pPacket, BYTE direction, DWORD ID, int x, int y, int HP);
void MakePacket_CreateOtherCharacter(PacketHeader* pHeader, PacketSCCreateOtherCharacter* pPacket, BYTE direction, DWORD ID, int x, int y, int HP);
void MakePacket_DeleteCharacter(PacketHeader* pHeader, PacketSCDeleteCharacter* pPacket, DWORD ID);

void MakePacket_MoveStart(PacketHeader* pHeader, PacketSCMoveStart* pPacket, BYTE direction, DWORD ID, int x, int y);
void MakePacket_MoveStop(PacketHeader* pHeader, PacketSCMoveStop* pPacket, BYTE direction, DWORD ID, int x, int y);

void MakePacket_Damage(PacketHeader* pHeader, PacketSCDamage* pPacket, DWORD attackID, DWORD damageID, BYTE damageHP);
void MakePacket_Attack1(PacketHeader* pHeader, PacketSCAttack1* pPacket, BYTE direction, DWORD ID, int x, int y);
void MakePacket_Attack2(PacketHeader* pHeader, PacketSCAttack2* pPacket, BYTE direction, DWORD ID, int x, int y);
void MakePacket_Attack3(PacketHeader* pHeader, PacketSCAttack3* pPacket, BYTE direction, DWORD ID, int x, int y);


void SendUnicast(Session* pSession, PacketHeader* pHeader, char* pPacket) noexcept;
void SendBroadcast(Session* pSession, PacketHeader* pHeader, char* pPacket) noexcept;
void Disconnect(Session* pSession) noexcept;

void ErrorHandler(const wchar_t* msg) noexcept;
void Logger(const wchar_t* msg) noexcept;


int _tmain(int argc, _TCHAR* argv[])
{
	// 콘솔 출력 UTF-8
	SetConsoleOutputCP(CP_UTF8);
	SetConsoleCP(CP_UTF8);

	// C/C++ 스트림 UTF-8 동기화
	system("chcp 65001 > nul");


	timeBeginPeriod(1);
	QueryPerformanceFrequency(&gFreq);
	QueryPerformanceCounter(&gFrameStartTick);

	// 윈속 초기화
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		ErrorHandler(L"WSAStartup fail");
	}
	// 로그
	Logger(L"WSAStartup #");

	gListenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (gListenSocket == INVALID_SOCKET)
		ErrorHandler(L"socket fail");

	u_long on = 1;
	int ioctRet = ioctlsocket(gListenSocket, FIONBIO, &on);
	if (ioctRet == SOCKET_ERROR)
		ErrorHandler(L"ioctlsocket fail");

	SOCKADDR_IN serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	int bindRet = bind(gListenSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
	if (bindRet == SOCKET_ERROR)
		ErrorHandler(L"WSAStartup fail");

	// 로그
	{
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"BIND OK # Port:%d", SERVER_PORT);
		Logger(buf);
	}
	int listenRet = listen(gListenSocket, SOMAXCONN);
	if (listenRet == SOCKET_ERROR)
		ErrorHandler(L"listen() fail");

	// 로그
	Logger(L"Listen OK #");


	// 설정 및 게임데이터, DB 데이터 로딩, 리슨 소켓 준비
	// 서버는 listen 함수를 호출함과 종시에 실질적인 ON 상태(접속자를 받는 상태)가 된다.

	while (!gbShutdown) // 서버 메인 루프, 전역의 gbShutdown 값에 의해 종료 설정
	{
		NetIOProcess(); // 네트워크 송수신 처리
		Update(); // 게임 로직 업데이트
	}


	// 서버의 종료 대기 서버는 함부로 종료하면 안된다.
	// DB에 저장 할 데이터나 기타 마무리 할 일들이 모두 끝났는지 확인한 뒤에 꺼주어야 한다.
	return 0;
}

void NetIOProcess() noexcept
{
	FD_SET readSet;
	FD_SET writeSet;

	FD_ZERO(&readSet);
	FD_ZERO(&writeSet);

	// 1. 리슨 소켓
	FD_SET(gListenSocket, &readSet);

	// 2. 세션 소켓들
	for (Session* session : gSessionList)
	{
		FD_SET(session->socket, &readSet);

		if (session->sendQ.GetUseSize() > 0)
		{
			FD_SET(session->socket, &writeSet);
		}
	}

	// 3. 타임아웃 설정 (논블로킹 select 처럼 사용)
	timeval time;
	time.tv_sec = 0;
	time.tv_usec = 0;

	int result = select(0, &readSet, &writeSet, nullptr, &time);

	if (result == SOCKET_ERROR)
	{
		ErrorHandler(L"Select fail");
		return;
	}

	if (result == 0)
	{
		// 처리할 소켓 없음
		return;
	}

	// 4. 리슨 소켓 처리 (accept)
	if (FD_ISSET(gListenSocket, &readSet))
	{
		--result;
		NetProc_Accept();
		if (result <= 0)
			return;
	}

	// 5. 각 세션 소켓 처리
	for (Session* session : gSessionList)
	{
		SOCKET s = session->socket;

		if (FD_ISSET(s, &readSet))
		{
			--result;
			NetProc_Recv(session);
			if (result <= 0)
				break;
		}

		if (result > 0 && FD_ISSET(s, &writeSet))
		{
			--result;
			NetProc_Send(session);
			if (result <= 0)
				break;
		}
	}
}



void Update() noexcept
{
	//... 적절한 게임 업데이트 처리 타이밍 계산 ... // 25fps or 50fps
	QueryPerformanceCounter(&gFrameEndTick);
	double elapsed = static_cast<double>(gFrameEndTick.QuadPart - gFrameStartTick.QuadPart) / gFreq.QuadPart;

	// 50 프레임
	if (elapsed <= 0.02)
	{
		return;
	}
	gFrameStartTick = gFrameEndTick;


	// 게임 업데이트 처리를 CPU 100%를 먹도록 해줄 순 없을 것입니다.
	// 가장 좋은 것은 네트워크 송수신 스레드와, 로직 스레드를 분리하고
	// 로직 스레드의 루프는 클라이언트 프레임에 대응되도록 맞추는 것입니다.
	// 지금 우리는 싱클 스레드로 네트워크 송수신 + 로직 로프가 함께 처리되어야 하는 상황이고
	// Sleep 같은 대리를 통해 로직 프레임을 제어하면 네트워크 송수신의 응답성이 너무 떨어지게 
	// 됩니다. 그래서 기본 루프는 최대한 빠르게 돌리며 네트워크 처리를 시도하고, 로직 프레임은
	// 클라이언트 프레임과 비슷하도록 로직을 돌릴 의도로 설계 하였습니다.
	for (auto& session : gSessionList)
	{
		// 사망처리
		if (0 >= session->HP)
		{
			Disconnect(session);
		}
		else
		{
			// 먼저 현재 좌표 기준으로 체크
			if (!MoveCheck(session->action, session->x, session->y))
				continue; // 범위 밖이면 이동 안 함

			// 실제 이동 처리
			switch (session->action)
			{
			case dfPACKET_MOVE_DIR_UU:
				session->y += dfMOVE_Y;
				break;

			case dfPACKET_MOVE_DIR_RR:
				session->x += dfMOVE_X;
				break;

			case dfPACKET_MOVE_DIR_RU:
				session->x += dfMOVE_X;
				session->y += dfMOVE_Y;
				break;

			case dfPACKET_MOVE_DIR_RD:
				session->x += dfMOVE_X;
				session->y -= dfMOVE_Y;
				break;

			case dfPACKET_MOVE_DIR_DD:
				session->y -= dfMOVE_Y;
				break;

			case dfPACKET_MOVE_DIR_LL:
				session->x -= dfMOVE_X;
				break;

			case dfPACKET_MOVE_DIR_LU:
				session->x -= dfMOVE_X;
				session->y += dfMOVE_Y;
				break;

			case dfPACKET_MOVE_DIR_LD:
				session->x -= dfMOVE_X;
				session->y -= dfMOVE_Y;
				break;

			default:
				break;
			}
		}
	}
}

bool MoveCheck(BYTE direction, int x, int y) noexcept
{
	int nx = x;
	int ny = y;

	switch (direction)
	{
	case dfPACKET_MOVE_DIR_UU: ny += dfMOVE_Y;         break;
	case dfPACKET_MOVE_DIR_DD: ny -= dfMOVE_Y;         break;
	case dfPACKET_MOVE_DIR_RR: nx += dfMOVE_X;         break;
	case dfPACKET_MOVE_DIR_LL: nx -= dfMOVE_X;         break;
	case dfPACKET_MOVE_DIR_RU: nx += dfMOVE_X; ny += dfMOVE_Y; break;
	case dfPACKET_MOVE_DIR_RD: nx += dfMOVE_X; ny -= dfMOVE_Y; break;
	case dfPACKET_MOVE_DIR_LU: nx -= dfMOVE_X; ny += dfMOVE_Y; break;
	case dfPACKET_MOVE_DIR_LD: nx -= dfMOVE_X; ny -= dfMOVE_Y; break;
	default:
		return false;
	}

	if (ny < dfRANGE_MOVE_TOP || ny > dfRANGE_MOVE_BOTTOM)
		return false;

	if (nx < dfRANGE_MOVE_LEFT || nx > dfRANGE_MOVE_RIGHT)
		return false;

	return true;
}


void NetProc_Accept() noexcept
{
	SOCKADDR_IN clientAddr;
	int addrlen = sizeof(clientAddr);
	SOCKET clientSocket = accept(gListenSocket, (SOCKADDR*)&clientAddr, &addrlen);
	if (clientSocket == INVALID_SOCKET)
	{
		Logger(L"clinetSocket accept fail");
		return;
	}

	Session* pSession = new Session;
	pSession->socket = clientSocket;
	pSession->addr = clientAddr;

	InetNtopW(AF_INET, &clientAddr.sin_addr, pSession->ipStr, _countof(pSession->ipStr));
	pSession->port = ntohs(clientAddr.sin_port);

	pSession->sessionID = gAllocID++;
	pSession->x = dfRANGE_MOVE_TOP + rand() % (dfRANGE_MOVE_BOTTOM - dfRANGE_MOVE_TOP + 1);
	pSession->y = dfRANGE_MOVE_LEFT + rand() % (dfRANGE_MOVE_RIGHT - dfRANGE_MOVE_LEFT + 1);
	pSession->direction = dfPACKET_MOVE_DIR_LL;
	pSession->HP = MAX_HP;

	gSessionList.push_back(pSession);

	//// 1) 로그인 패킷 보내기
	PacketHeader packetHeader;
	PacketSCCreateMyCharacter createMyCharacter;
	MakePacket_CreateMyCharacter(&packetHeader, &createMyCharacter, pSession->direction, pSession->sessionID, pSession->x, pSession->y, pSession->HP);
	SendUnicast(pSession, &packetHeader, (char*)&createMyCharacter);

	//// 2) 기존 유저들 → 신규 유저에게
	for (auto& other : gSessionList)
	{
		if (other == pSession)
			continue;

		PacketHeader otherPacketHeader;
		PacketSCCreateOtherCharacter createOtherCharacter;
		MakePacket_CreateOtherCharacter(&otherPacketHeader, &createOtherCharacter, other->direction, other->sessionID, other->x, other->y, other->HP);
		SendUnicast(pSession, &otherPacketHeader, (char*)&createOtherCharacter);
	}

	//// 3) 신규 유저 → 전체 유저에게 브로드캐스트
	PacketHeader broadPacketHeader;
	PacketSCCreateOtherCharacter broadCreateOtherCharacter;
	MakePacket_CreateOtherCharacter(&broadPacketHeader, &broadCreateOtherCharacter, pSession->direction, pSession->sessionID, pSession->x, pSession->y, pSession->HP);
	SendBroadcast(pSession, &broadPacketHeader, (char*)&broadCreateOtherCharacter);

	wchar_t buf[256];
	_snwprintf_s(buf, 256, _TRUNCATE,
		L"Connect # IP:%s / SessionID:%d", pSession->ipStr, pSession->sessionID);
	Logger(buf);
	_snwprintf_s(buf, 256, _TRUNCATE,
		L"# PACKET_CONNECT # SessionID:%d", pSession->sessionID);
	Logger(buf);
	_snwprintf_s(buf, 256, _TRUNCATE,
		L"Create Character # SessionID:%d    X:%d    Y:%d", pSession->sessionID, pSession->x, pSession->y);
	Logger(buf);
}

void NetProc_Recv(Session* pSession) noexcept
{
	// 임시 수신버퍼 선언, 한번에 받을 수 있는 최대 크기의 버퍼 1000 ~ 10000 바이트
	// 패킷용 임시버퍼 모든 타입의 패킷을 처리할 수 있는 넉넉한 사이즈
	char buffer[BUFFER_SIZE];
	memset(buffer, 0, sizeof(buffer));

	// recv 호출 (임시 수신 버퍼로)
	int recvRet = recv(pSession->socket, buffer, sizeof(buffer), 0);
	// recv 리턴값으로 종료 (0) / 에러 (SOCKET_ERROR) 처리
	// 데이터를 받았다면 일단 RecvQ에 무작정 넣음.
	if (recvRet == 0)
	{
		Disconnect(pSession);
	}
	else if (recvRet == SOCKET_ERROR)
	{
		if (WSAGetLastError() != WSAEWOULDBLOCK) {
			Disconnect(pSession);
		}
	}

	pSession->recvQ.Enqueue(buffer, recvRet);

	// * 완료 패킷 처리 부
	// 완료 패킷 처리 부분은 RecvQ에 들어 있는 모든 완성패킷을 처리해야 함.
	while (1)
	{
		// 1. RecvQ() 에 최소한의 사이즈가 있는지 확인.조건 = 헤더사이즈 초과
		size_t packetHeaderSize = sizeof(PacketHeader);
		if (pSession->recvQ.GetUseSize() < packetHeaderSize)
		{
			break;
		}

		// 2. RecvQ() 에서 헤더를 Peek();
		PacketHeader packetHeader;
		pSession->recvQ.Peek(reinterpret_cast<char*>(&packetHeader), packetHeaderSize);

		// 3. 헤더의 Code 확인
		if (packetHeader.code != dfNETWORK_PACKET_CODE) {
			Disconnect(pSession);
			return;
		}

		// 4. 헤더의 Len 값과 RecvQ의 데이터 사이즈비교 (완성 패킷 사이즈 : 헤더 + Len)
		if (pSession->recvQ.GetUseSize() < packetHeader.size)
			return;

		// 5. 데이터 Peek 했던 헤더를 RecvQ에서 지우고(이미 빼두었으므로 또 뺄 필요 없음)
		pSession->recvQ.MoveFront(packetHeaderSize);

		// 6. RecvQ 에서 Len 만큼 임시 패킷 버퍼로 뽑음.
		// 페이로드 부분을 임시 패킷 버퍼로 뽑음.
		const int payloadSize = packetHeader.size - static_cast<int>(packetHeaderSize);
		char packetBuffer[BUFFER_SIZE]; // 패킷 바디 임시 버퍼
		if (payloadSize > BUFFER_SIZE)
		{
			// 말이 안 되는 패킷 사이즈 → 프로토콜 위반으로 보고 끊어버림
			Disconnect(pSession);
			return;
		}
		pSession->recvQ.Dequeue(packetBuffer, payloadSize);

		// 7. 헤더의 타입에 따른 분기를 위해 패킷 프로시저 호출
		PacketProc(pSession, packetHeader.type, packetBuffer);
	}
}

void NetProc_Send(Session* pSession) noexcept
{
	// 한번에 보낼 최대 크기 (recv랑 대칭)
	char buffer[BUFFER_SIZE];

	while (true)
	{
		const int useSize = static_cast<int>(pSession->sendQ.GetUseSize());
		if (useSize <= 0)
		{
			// 보낼 데이터 없음
			break;
		}

		// 이번에 보낼 크기 결정 (버퍼보다 크면 잘라서 보냄)
		int sendSize = useSize;
		if (sendSize > BUFFER_SIZE)
			sendSize = BUFFER_SIZE;

		// 1) sendQ에서 보낼 데이터 미리 보기 (복사만 하고 front는 안 움직임)
		pSession->sendQ.Peek(buffer, sendSize);

		// 2) 소켓으로 전송
		int sendRet = send(pSession->socket, buffer, sendSize, 0);

		if (sendRet == 0)
		{
			// 정상 종료로 간주 → 세션 종료
			Disconnect(pSession);
			return;
		}
		else if (sendRet == SOCKET_ERROR)
		{
			const int err = WSAGetLastError();

			if (err == WSAEWOULDBLOCK)
			{
				// 지금은 더 못 보냄 → 다음 Tick에서 다시 시도
				return;
			}

			// 그 외 에러는 비정상 → 끊어버림
			Disconnect(pSession);
			return;
		}

		// 3) 실제로 전송된 만큼 sendQ에서 제거
		pSession->sendQ.MoveFront(sendRet);
	}
}


bool PacketProc(Session* pSession, BYTE byPacketType, char* pPacket)
{
	switch (byPacketType)
	{
	case dfPACKET_CS_MOVE_START:
		return NetPacketProc_MoveStart(pSession, pPacket);
		break;
	case dfPACKET_CS_MOVE_STOP:
		return NetPacketProc_MoveStop(pSession, pPacket);
		break;
	case dfPACKET_CS_ATTACK1:
		return NetPacketProc_Attack1(pSession, pPacket);
		break;
	case dfPACKET_CS_ATTACK2:
		return NetPacketProc_Attack2(pSession, pPacket);
		break;
	case dfPACKET_CS_ATTACK3:
		return NetPacketProc_Attack3(pSession, pPacket);
		break;
	}
	return TRUE;
}

bool NetPacketProc_MoveStart(Session* pSession, char* pPacket)
{
	PacketCSMoveStart* pMoveStart = (PacketCSMoveStart*)pPacket;
	if (abs(pMoveStart->x - pSession->x) > dfERROR_RANGE ||
		abs(pMoveStart->y - pSession->y) > dfERROR_RANGE)
	{
		Disconnect(pSession);
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"dfERROR_RANGE Fail ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
		Logger(buf);
		return false;
	}

	// 동작을 변경. 지금 구현에선 동작 번호가 방향값이다.
	pSession->action = pMoveStart->direction;

	// 방향을 변경
	switch (pMoveStart->direction)
	{
	case dfPACKET_MOVE_DIR_RR:
	case dfPACKET_MOVE_DIR_RU:
	case dfPACKET_MOVE_DIR_RD:
		pSession->direction = dfPACKET_MOVE_DIR_RR;
		break;
	case dfPACKET_MOVE_DIR_LU:
	case dfPACKET_MOVE_DIR_LL:
	case dfPACKET_MOVE_DIR_LD:
		pSession->direction = dfPACKET_MOVE_DIR_LL;
		break;
	}
	pSession->x = pMoveStart->x;
	pSession->y = pMoveStart->y;

	PacketHeader packetHeader;
	PacketSCMoveStart sendMsg;
	MakePacket_MoveStart(&packetHeader, &sendMsg, pSession->sessionID, pSession->direction, pSession->x, pSession->y);
	SendBroadcast(pSession, &packetHeader, (char*)&sendMsg); // 당사자만 제외하고 모두에게 전송시키는 함수

	return true;
}

bool NetPacketProc_MoveStop(Session* pSession, char* pPacket)
{
	PacketCSMoveStop* pMoveStop = (PacketCSMoveStop*)pPacket;
	if (abs(pMoveStop->x - pSession->x) > dfERROR_RANGE ||
		abs(pMoveStop->y - pSession->y) > dfERROR_RANGE)
	{
		Disconnect(pSession);
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"dfERROR_RANGE Fail ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
		Logger(buf);
		return false;
	}

	// 동작을 변경. 지금 구현에선 동작 번호가 방향값이다.
	pSession->action = pMoveStop->direction;

	// 방향을 변경
	switch (pMoveStop->direction)
	{
	case dfPACKET_MOVE_DIR_RR:
	case dfPACKET_MOVE_DIR_RU:
	case dfPACKET_MOVE_DIR_RD:
		pSession->direction = dfPACKET_MOVE_DIR_RR;
		break;
	case dfPACKET_MOVE_DIR_LU:
	case dfPACKET_MOVE_DIR_LL:
	case dfPACKET_MOVE_DIR_LD:
		pSession->direction = dfPACKET_MOVE_DIR_LL;
		break;
	}
	pSession->x = pMoveStop->x;
	pSession->y = pMoveStop->y;

	PacketHeader packetHeader;
	PacketSCMoveStop sendMsg;
	MakePacket_MoveStop(&packetHeader, &sendMsg, pSession->sessionID, pSession->direction, pSession->x, pSession->y);
	SendBroadcast(pSession, &packetHeader, (char*)&sendMsg); // 당사자만 제외하고 모두에게 전송시키는 함수

	return true;
}

bool NetPacketProc_Attack1(Session* pSession, char* pPacket)
{
	PacketCSAttack1* packetATK1 = (PacketCSAttack1*)pPacket;

	// 공격 범위가 이동 범위 이상이면 제거
	if (abs(packetATK1->x - pSession->x) > dfERROR_RANGE ||
		abs(packetATK1->y - pSession->y) > dfERROR_RANGE)
	{
		Disconnect(pSession);
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"Attack dfERROR_RANGE Fail ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
		Logger(buf);
		return false;
	}

	// 동작을 변경. 지금 구현에선 동작 번호가 방향값이다.
	pSession->action = packetATK1->direction;

	// 방향을 변경
	switch (packetATK1->direction)
	{
	case dfPACKET_MOVE_DIR_RR:
	case dfPACKET_MOVE_DIR_RU:
	case dfPACKET_MOVE_DIR_RD:
		pSession->direction = dfPACKET_MOVE_DIR_RR;
		break;
	case dfPACKET_MOVE_DIR_LU:
	case dfPACKET_MOVE_DIR_LL:
	case dfPACKET_MOVE_DIR_LD:
		pSession->direction = dfPACKET_MOVE_DIR_LL;
		break;
	}

	for (auto& session : gSessionList)
	{
		if (abs(packetATK1->x - session->x) > dfATTACK1_RANGE_X ||
			abs(packetATK1->y - session->y) > dfATTACK1_RANGE_Y)
		{
			continue;
		}

		PacketHeader packetHeader;
		PacketSCDamage sendMsg;
		MakePacket_Damage(&packetHeader, &sendMsg, pSession->sessionID, session->sessionID, dfATTACK1_DAMAGE);
		// 질문) 여기에 nullptr을 넣어도 되는가?
		SendBroadcast(nullptr, &packetHeader, (char*)&sendMsg);

		session->HP -= dfATTACK1_DAMAGE;
	}

	return true;
}

bool NetPacketProc_Attack2(Session* pSession, char* pPacket)
{
	PacketCSAttack2* packetATK2 = (PacketCSAttack2*)pPacket;

	// 공격 범위가 이동 범위 이상이면 제거
	if (abs(packetATK2->x - pSession->x) > dfERROR_RANGE ||
		abs(packetATK2->y - pSession->y) > dfERROR_RANGE)
	{
		Disconnect(pSession);
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"Attack dfERROR_RANGE Fail ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
		Logger(buf);
		return false;
	}

	// 동작을 변경. 지금 구현에선 동작 번호가 방향값이다.
	pSession->action = packetATK2->direction;

	// 방향을 변경
	switch (packetATK2->direction)
	{
	case dfPACKET_MOVE_DIR_RR:
	case dfPACKET_MOVE_DIR_RU:
	case dfPACKET_MOVE_DIR_RD:
		pSession->direction = dfPACKET_MOVE_DIR_RR;
		break;
	case dfPACKET_MOVE_DIR_LU:
	case dfPACKET_MOVE_DIR_LL:
	case dfPACKET_MOVE_DIR_LD:
		pSession->direction = dfPACKET_MOVE_DIR_LL;
		break;
	}

	for (auto& session : gSessionList)
	{
		if (abs(packetATK2->x - session->x) > dfATTACK2_RANGE_X ||
			abs(packetATK2->y - session->y) > dfATTACK2_RANGE_Y)
		{
			continue;
		}

		PacketHeader packetHeader;
		PacketSCDamage sendMsg;
		MakePacket_Damage(&packetHeader, &sendMsg, pSession->sessionID, session->sessionID, dfATTACK2_DAMAGE);
		// 질문) 여기에 nullptr을 넣어도 되는가?
		SendBroadcast(nullptr, &packetHeader, (char*)&sendMsg);

		session->HP -= dfATTACK2_DAMAGE;
	}

	return true;
}

bool NetPacketProc_Attack3(Session* pSession, char* pPacket)
{
	PacketCSAttack3* packetATK3 = (PacketCSAttack3*)pPacket;

	// 공격 범위가 이동 범위 이상이면 제거
	if (abs(packetATK3->x - pSession->x) > dfERROR_RANGE ||
		abs(packetATK3->y - pSession->y) > dfERROR_RANGE)
	{
		Disconnect(pSession);
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"Attack dfERROR_RANGE Fail ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
		Logger(buf);
		return false;
	}

	// 동작을 변경. 지금 구현에선 동작 번호가 방향값이다.
	pSession->action = packetATK3->direction;

	// 방향을 변경
	switch (packetATK3->direction)
	{
	case dfPACKET_MOVE_DIR_RR:
	case dfPACKET_MOVE_DIR_RU:
	case dfPACKET_MOVE_DIR_RD:
		pSession->direction = dfPACKET_MOVE_DIR_RR;
		break;
	case dfPACKET_MOVE_DIR_LU:
	case dfPACKET_MOVE_DIR_LL:
	case dfPACKET_MOVE_DIR_LD:
		pSession->direction = dfPACKET_MOVE_DIR_LL;
		break;
	}

	for (auto& session : gSessionList)
	{
		if (abs(packetATK3->x - session->x) > dfATTACK3_RANGE_X ||
			abs(packetATK3->y - session->y) > dfATTACK3_RANGE_Y)
		{
			continue;
		}

		PacketHeader packetHeader;
		PacketSCDamage sendMsg;
		MakePacket_Damage(&packetHeader, &sendMsg, pSession->sessionID, session->sessionID, dfATTACK3_DAMAGE);
		// 질문) 여기에 nullptr을 넣어도 되는가?
		SendBroadcast(nullptr, &packetHeader, (char*)&sendMsg);

		session->HP -= dfATTACK3_DAMAGE;
	}

	return true;
}



// 에러
void ErrorHandler(const wchar_t* msg) noexcept
{
	int err = WSAGetLastError();
	wprintf(L"ERROR: %s, WSAGetLastError : %d\n", msg, err);
	::WSACleanup();
	abort();
}

// 로그
void Logger(const wchar_t* msg) noexcept
{
	wprintf(L"%s\n", msg);
}

void MakePacket_CreateMyCharacter(PacketHeader* pHeader, PacketSCCreateMyCharacter* pPacket, BYTE direction, DWORD ID, int x, int y, int HP)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCCreateMyCharacter);
	pHeader->type = dfPACKET_SC_CREATE_MY_CHARACTER;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
	pPacket->HP = HP;
}

void MakePacket_CreateOtherCharacter(PacketHeader* pHeader, PacketSCCreateOtherCharacter* pPacket, BYTE direction, DWORD ID, int x, int y, int HP)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCCreateOtherCharacter);
	pHeader->type = dfPACKET_SC_CREATE_OTHER_CHARACTER;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
	pPacket->HP = HP;
}

void MakePacket_DeleteCharacter(PacketHeader* pHeader, PacketSCDeleteCharacter* pPacket, DWORD ID)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCDeleteCharacter);
	pHeader->type = dfPACKET_SC_DELETE_CHARACTER;

	pPacket->ID = ID;
}

void MakePacket_MoveStart(PacketHeader* pHeader, PacketSCMoveStart* pPacket, BYTE direction, DWORD ID, int x, int y)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCMoveStart);
	pHeader->type = dfPACKET_SC_MOVE_START;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
}

void MakePacket_MoveStop(PacketHeader* pHeader, PacketSCMoveStop* pPacket, BYTE direction, DWORD ID, int x, int y)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCMoveStop);
	pHeader->type = dfPACKET_SC_MOVE_STOP;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
}

void MakePacket_Damage(PacketHeader* pHeader, PacketSCDamage* pPacket, DWORD attackID, DWORD damageID, BYTE damageHP)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCDamage);
	pHeader->type = dfPACKET_SC_DAMAGE;

	pPacket->attackID = attackID;
	pPacket->damageID = damageID;
	pPacket->damageHP = damageHP;
}

void MakePacket_Attack1(PacketHeader* pHeader, PacketSCAttack1* pPacket, BYTE direction, DWORD ID, int x, int y)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCAttack1);
	pHeader->type = dfPACKET_SC_ATTACK1;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
}

void MakePacket_Attack2(PacketHeader* pHeader, PacketSCAttack2* pPacket, BYTE direction, DWORD ID, int x, int y)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCAttack2);
	pHeader->type = dfPACKET_SC_ATTACK2;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
}

void MakePacket_Attack3(PacketHeader* pHeader, PacketSCAttack3* pPacket, BYTE direction, DWORD ID, int x, int y)
{
	pHeader->code = dfNETWORK_PACKET_CODE;
	pHeader->size = sizeof(PacketHeader) + sizeof(PacketSCAttack3);
	pHeader->type = dfPACKET_SC_ATTACK3;

	pPacket->ID = ID;
	pPacket->direction = direction;
	pPacket->x = x;
	pPacket->y = y;
}

void SendUnicast(Session* pSession, PacketHeader* pHeader, char* pPacket) noexcept
{
	if (pSession->sendQ.GetFreeSize() < pHeader->size)
	{
		Disconnect(pSession);
		Logger(L"sendQ is full, disconnect");
		wchar_t buf[256];
		_snwprintf_s(buf, 256, _TRUNCATE,
			L"sendQ is full ID=%d IP=%s",
			pSession->sessionID, pSession->ipStr);
	}

	pSession->sendQ.Enqueue((char*)pHeader, sizeof(pHeader));
	pSession->sendQ.Enqueue(pPacket, sizeof(pHeader->size) - sizeof(pHeader));
}

void SendBroadcast(Session* pSession, PacketHeader* pHeader, char* pPacket) noexcept
{
	for (auto& session : gSessionList)
	{
		if (session == pSession)
			continue;

		// sendQ가 꽉차면... 
		// TODO 이걸 넣을 때마다 검사하지 말고 그냥 꽉차면 연결 끊게 내부구현을 해야되나..?
		if (session->sendQ.GetFreeSize() < pHeader->size)
		{
			Disconnect(session);
			Logger(L"sendQ is full, disconnect");
			wchar_t buf[256];
			_snwprintf_s(buf, 256, _TRUNCATE,
				L"sendQ is full ID=%d IP=%s",
				pSession->sessionID, pSession->ipStr);
		}

		session->sendQ.Enqueue((char*)pHeader, sizeof(pHeader));
		session->sendQ.Enqueue(pPacket, sizeof(pHeader->size) - sizeof(pHeader));
	}
}

void Disconnect(Session* pSession) noexcept
{
	PacketHeader pHeader;
	PacketSCDeleteCharacter pPacket;
	MakePacket_DeleteCharacter(&pHeader, &pPacket, pSession->sessionID);

	SendBroadcast(pSession, &pHeader, (char*)&pPacket);

	closesocket(pSession->socket);

	gSessionList.remove(pSession);
	delete pSession;
}